﻿using DataLibrary.ResponseFields;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventModels.ResponseFields
{
    public class StaffPage
    {
        public List<StaffResponse> StaffResponses { get; set; }
    }
}
