﻿using DataLibrary.ResponseFields;
using System.Collections.Generic;

namespace AdventModels.ResponseFields
{
    public class StockPage
    {
        public List<StockResponse> StockResponses { get; set; }
    }
}
